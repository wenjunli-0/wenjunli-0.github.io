import json
import re
import sys

import fire
import numpy as np

"""
Example usage:

python tests/02_reward_function.py --file_name Qwen_Qwen2.5-Math-1.5B_500_8_0.3.json --n_samples 8
"""


keyword_pool_gpt = {
    # Re-evaluation and rechecking
    "recheck": 0, 
    "rethink": 0, 
    "reevaluate": 0, 
    "re-evaluate": 0, 
    "reevaluation": 0, 
    "re-examine": 0, 
    "reexamine": 0, 
    "review": 0,
    "revisit": 0,
    "reassess": 0,
    "reconsider": 0,
    "reanalyse": 0,
    "reanalyze": 0,
    
    # Attempts and retries
    "try again": 0, 
    "check again": 0, 
    "think again": 0, 
    "go over the steps again": 0, 
    "go over the steps": 0,
    "give it another try": 0,
    "make another attempt": 0,
    "let me reconsider": 0,
    "take another look": 0,
    
    # Verification and double-checking
    "double-check": 0,
    "verify again": 0,
    "cross-check": 0,
    "confirm once more": 0,
    "validate again": 0,
    
    # Acknowledgment of errors or uncertainty
    "I may have overlooked": 0,
    "let me recheck": 0,
    "I might be wrong": 0,
    "let me confirm": 0,
    "let me revise": 0,
    "upon reflection": 0,
    "after reconsidering": 0,
    "let me think this through": 0,
}


def main(detection_mode: str = "keyword"):
    file_list = [
        # fm, r1_v2
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.1_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.2_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.3_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.4_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.5_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.6_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.7_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.8_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.9_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_1.0_r1_v2.json",

        # deepseek, v3
        "deepseek_v3_base_truncated_500_8_0.1_r1.json",
        "deepseek_v3_base_truncated_500_8_0.2_r1.json",
        "deepseek_v3_base_truncated_500_8_0.3_r1.json",
        "deepseek_v3_base_truncated_500_8_0.4_r1.json",
        "deepseek_v3_base_truncated_500_8_0.5_r1.json",
        "deepseek_v3_base_truncated_500_8_0.6_r1.json",
        "deepseek_v3_base_truncated_500_8_0.7_r1.json",
        "deepseek_v3_base_truncated_500_8_0.8_r1.json",
        "deepseek_v3_base_truncated_500_8_0.9_r1.json",
        "deepseek_v3_base_truncated_500_8_1.0_r1.json",

        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.1.json",
        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.2.json",
        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.3.json",
        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.4.json",
        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.5.json",
        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.6.json",
        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.7.json",
        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.8.json",
        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.9.json",
        # "Qwen_Qwen2.5-Math-1.5B_500_8_1.0.json",

        # "Qwen_Qwen2.5-Math-7B_500_8_0.1.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_0.2.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_0.3.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_0.4.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_0.5.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_0.6.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_0.7.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_0.8.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_0.9.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_1.0.json",

        # "Qwen_Qwen2.5-7B_500_8_0.1.json",
        # "Qwen_Qwen2.5-7B_500_8_0.2.json",
        # "Qwen_Qwen2.5-7B_500_8_0.3.json",
        # "Qwen_Qwen2.5-7B_500_8_0.4.json",
        # "Qwen_Qwen2.5-7B_500_8_0.5.json",
        # "Qwen_Qwen2.5-7B_500_8_0.6.json",
        # "Qwen_Qwen2.5-7B_500_8_0.7.json",
        # "Qwen_Qwen2.5-7B_500_8_0.8.json",
        # "Qwen_Qwen2.5-7B_500_8_0.9.json",
        # "Qwen_Qwen2.5-7B_500_8_1.0.json",

        # deepseek-math-7b, r1_v2
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.1_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.2_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.3_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.4_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.5_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.6_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.7_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.8_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.9_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_1.0_r1_v2.json",

        # rho, qwen template
        # "microsoft_rho-math-7b-v0.1_500_8_0.1.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.2.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.3.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.4.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.5.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.6.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.7.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.8.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.9.json",
        # "microsoft_rho-math-7b-v0.1_500_8_1.0.json",

        # llama-3.1-8b, r1_v2
        # "meta-llama_Llama-3.1-8B_500_8_0.1_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.2_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.3_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.4_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.5_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.6_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.7_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.8_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.9_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_1.0_r1_v2.json",
    ]

    sr_per_response_list = []
    sr_per_response_keyword_list = []
    sr_per_response_llm_list = []
    for temp, file_name in enumerate(file_list):
        file_name = f'responses_llm/{file_name}'
        output = json.load(open(file_name))
        print(f'Processing {file_name}. Temperature = 0.{temp+1}')

        # v0 is the one always use, from the beginning
        keyword_pool_v0 = {
            "recheck": 0, 
            "rethink": 0, 

            "reevaluate": 0, 
            "re-evaluate": 0, 
            "reevaluation": 0, 
            
            "re-examine": 0, 
            "reexamine": 0, 

            "try again": 0, 
            "check again": 0, 
            "think again": 0, 
            "go over the steps": 0,
        }

        # v1 is expanded upon v0
        keyword_pool_v1 = {
            "recheck": 0, 
            "rethink": 0, 
            "reassess": 0,

            "reevaluate": 0, 
            "re-evaluate": 0, 
            "reevaluation": 0, 
            
            "re-examine": 0, 
            "reexamine": 0, 

            "reconsider": 0,
            "reanalyze": 0,
            "double-check": 0,

            "check again": 0, 
            "think again": 0, 
            "verify again": 0,
            "go over the steps": 0,
        }

        sr_per_response = 0
        sr_per_response_keyword = 0
        sr_per_response_llm = 0
        for idx, o in enumerate(output):
            response = o['response'].lower()  # Make it case-insensitive

            if detection_mode == "keyword":     
            # keyword-based detection
                for keyword in keyword_pool_v1:
                    keyword_pool_v1[keyword] += response.count(keyword)

            elif detection_mode == "combined":
                # cross-checking by keyword- and llm-based detection
                keyword_detected = False
                llm_detected = False

                for keyword in keyword_pool_v1:
                    if response.count(keyword) > 0:
                        keyword_detected = True
                        sr_per_response_keyword += 1
                        break
                
                if 'Qwen' in file_name or 'deepseek_v3' in file_name or 'microsoft' in file_name:
                    response_text = o['llm_check_2'][-3:]
                else:
                    response_text = o['llm_check'][-3:]
                if '2' in response_text:
                    llm_detected = True
                    sr_per_response_llm += 1

                if keyword_detected and llm_detected:
                    sr_per_response += 1

        sr_per_response_list.append(sr_per_response)
        sr_per_response_keyword_list.append(sr_per_response_keyword)
        sr_per_response_llm_list.append(sr_per_response_llm)
        
        if detection_mode == "keyword":
            print(f'keyword_pool_v1 = {keyword_pool_v1} \n')
        elif detection_mode == "llm":
            pass
        elif detection_mode == "combined":
            print(f'sr_per_response={sr_per_response}; keyword={sr_per_response_keyword}; llm={sr_per_response_llm}')

    if detection_mode == "combined":
        if detection_mode == "keyword":
            print(f'keyword_pool_v1 = {keyword_pool_v1} \n')
        elif detection_mode == "llm":
            pass
        elif detection_mode == "combined":
            print(f'keyword={sr_per_response_keyword_list}; llm={sr_per_response_llm_list}; sr_combined={sr_per_response_list}')

fire.Fire(main)