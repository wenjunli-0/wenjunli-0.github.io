import json
import re
import sys

import fire
import numpy as np

import os
from openai import OpenAI

# from oat_zero.qwen_math_eval_toolkit.grader import math_equal
# from oat_zero.qwen_math_eval_toolkit.parser import extract_answer as math_extract_answer
from reward_func import extract_answer, grade_answer_mathd, grade_answer_sympy


"""
Example usage:

cd /careAIDrive/wenjun/r1_replication/oat-zero/
module purge
module load Anaconda3
eval "$(conda shell.bash hook)"
conda activate llm

# qwen template
python tests/04_reflection_check_llm.py --file_name Qwen_Qwen2.5-Math-1.5B_500_8_1.0.json --n_samples 8
python tests/04_reflection_check_llm.py --file_name Qwen_Qwen2.5-Math-7B_500_8_0.1.json --n_samples 8
python tests/04_reflection_check_llm.py --file_name Qwen_Qwen2.5-7B_500_8_0.1.json --n_samples 8
python tests/04_reflection_check_llm.py --file_name microsoft_rho-math-7b-v0.1_500_8_0.1.json --n_samples 8

# r1 template
python tests/04_reflection_check_llm.py --file_name meta-llama_Llama-3.1-8B_500_8_0.1_r1.json --n_samples 8
python tests/04_reflection_check_llm.py --file_name HuggingFaceTB_FineMath-Llama-3B_500_8_0.1_r1.json --n_samples 8
python tests/04_reflection_check_llm.py --file_name deepseek-ai_deepseek-math-7b-base_500_8_0.1_r1.json --n_samples 8

python tests/04_reflection_check_llm.py --file_name deepseek_v3_base_truncated_500_8_0.1_r1.json --n_samples 8

# r1 template, v2
python tests/04_reflection_check_llm.py --file_name meta-llama_Llama-3.1-8B_500_8_0.1_r1_v2.json --n_samples 8
python tests/04_reflection_check_llm.py --file_name HuggingFaceTB_FineMath-Llama-3B_500_8_0.1_r1_v2.json --n_samples 8
python tests/04_reflection_check_llm.py --file_name deepseek-ai_deepseek-math-7b-base_500_8_0.1_r1_v2.json --n_samples 8
"""

def preprocess_box_response_for_qwen_prompt(sequence, answer):
    # breakpoint()
    model_output = re.sub(
        r"^.*?<\|im_start\|>assistant",
        "<|im_start|>assistant",
        sequence,
        flags=re.DOTALL,
        count=1,
    )
    stop_words = ["</s>", "<|im_end|>", "<|endoftext|>"]
    for stop_word in stop_words:
        if stop_word in model_output:
            model_output = model_output.split(stop_word)[0].strip()
    extract_answer = math_extract_answer(
        model_output, data_name="math"
    )  # TODO: check the data_name, hard code here for now

    if math_equal(prediction=extract_answer, reference=answer):
        box_match = 1.0
    else:
        box_match = -0.5

    if "boxed" not in model_output:
        box_match = -1.0

    return "", box_match


def grade(model_answer: str, gt_answer: str):
    if "\\boxed" in gt_answer:
        gt_answer = extract_answer(gt_answer)
    return grade_answer_mathd(model_answer, gt_answer) or grade_answer_sympy(
        model_answer, gt_answer
    )


def math_reward_fn(model_response, gt_answer):
    if "</answer>" in model_response:
        model_response = model_response[:model_response.find("</answer>") + len("</answer>")]
    if "</think> <answer>" in model_response and "</answer>" in model_response:
    # if "</answer>" in model_response:
        model_answer = model_response.split("<answer>")[-1].replace("</answer>", "")
        if "\\boxed" in model_answer:
            model_answer = extract_answer(model_answer)
            if model_answer is None:
                return {"formatted": True}, 0.0
        if isinstance(gt_answer, float) or isinstance(gt_answer, int):
            gt_answer = str(gt_answer)
        if isinstance(gt_answer, str):
            is_correct = grade(model_answer, gt_answer)
        elif isinstance(gt_answer, list):
            is_correct = False
            for gt in gt_answer:
                is_correct |= grade(model_answer, gt)
        if is_correct:
            return {"formatted": True}, 1.0  # Correctness reward.
        else:
            return (
                {"formatted": True},
                0.0,
            )  # Formatted but wrong answer; no format reward to avoid hacking.
    else:
        return {"formatted": False}, 0.0  # Unformatted.
       

def main(file_name: str = "output_Qwen_Qwen2.5-Math-7B_1000.json", n_samples: int = 1):
    # v1
#     instruction = """I will send you a long response to a math problem. Your task is to categorize the response into one of the following groups:

# ### **Categorization Rules**:

# - **Category 0**: Some responses may be nonsensical or filled with repetitive words. If the response lacks meaningful content, coherence, or logical reasoning, **mark it as 0**.
  
# - **Category 1**: Some responses contain chain-of-thought (CoT), where the problem is broken down into multiple intermediate steps leading to the final conclusion. **Mark it as 1**.
  
# - **Category 2**: Some responses contain self-reflection. This may include:
#   - **Explicit keywords** such as: recheck, rethink, reevaluate, re-evaluate, reevaluation, re-examine, try again, check again, think again, go over the steps again, go over the steps, etc.
#   - **More sophisticated or implicit self-reflection patterns** without explicit keywords (e.g., revisiting or double-checking the solution, considering alternative approaches).
  
#   **Mark it as 2** if the response contains any form of self-reflection.

# - **Category 3**: The response contains calculations or rechecks using Python code. **Mark it as 3**. If the response includes both self-reflection and Python code, assign **Category 2** (not 3).

# ### **Output Format**:

# Your response must start with a **single integer** (0, 1, 2, or 3), followed by a **brief explanation** (except for Category 0). 

# - **Return 0** → The response is nonsensical, incoherent, or overly repetitive.  
#   *Example output:* `0.`  

# - **Return 1** → The response follows a CoT structure.  
#   *Example output:* `1: The response breaks the problem into intermediate steps leading to the conclusion.`  

# - **Return 2** → The response contains self-reflection (either explicit keywords or implicit patterns of revisiting the solution).  
#   *Example output:* `2: The response contains keywords like "recheck" or revisits the solution in more depth.`  

# - **Return 3** → The response contains calculations or rechecks using Python code, with no self-reflection.  
#   *Example output:* `3: The response includes Python code to verify the solution.`  

# Here is the response:  
# {response}
# """

    # v2
#     instruction = """I will send you a mathematical question and a long response to the question. Your task is to determine whether the response is trying to answer the question. If the response is off-topic, hallucination, random talk, or any other irrelevant content, then mark it as 0. Otherwise, categorize the response into one of the following groups:

# ### **Categorization Rules**:

# If the response is off-topic, nonsensical, filled with repetitive words, lacks meaningful content, coherence, etc., **mark it as 0**.
# - **Category 0**: The response is nonsensical, incoherent, overly repetitive, or lacks logical reasoning.

# If the response is trying to answer the question, regardless of the correctness or answer quality, categorize it into one of the following groups:
# - **Category 1**: The response follows a chain-of-thought (CoT) structure, breaking the problem into multiple intermediate steps leading to the final conclusion.

# - **Category 2**: The response contains self-reflection. This may include:
#   - **Explicit keywords** such as: recheck, rethink, reevaluate, re-evaluate, reevaluation, re-examine, try again, check again, think again, go over the steps again, go over the steps, etc.
#   - **More sophisticated or implicit self-reflection patterns** without explicit keywords (e.g., revisiting or double-checking the solution, considering alternative approaches).

#   If the response shows any form of self-reflection, **prioritize Category 2** over any other category.

# - **Category 3**: The response solely uses Python code for calculations without showing any self-reflection or rechecking pattern. If the response includes both self-reflection and Python code, **assign Category 2** (not 3).

# ### **Output Format**:

# Your response must first provide a **very brief explanation** of your analysis and then state the **single category number** (0, 1, 2, or 3) at the end. You must include the category number at the end of your response.

# *Example output:*
# - `The response is off-topic and contains irrelevant information without attempting to solve the question. 0.`
# - `The response breaks the problem into intermediate steps and follows a chain-of-thought approach. 1.`
# - `The response revisits the solution, considering alternative approaches and double-checking the steps. 2.`
# - `The response uses Python code to calculate the solution without showing any self-reflection. 3.`

# Question: {question}
# Response: {response}
# """

    # v3
    instruction = """I will send you a mathematical question and a long response to the question. Your task is to determine whether the response is trying to answer the question. If the response is off-topic, hallucination, random talk, or any other irrelevant content, then mark it as 0. Otherwise, categorize the response into one of the following groups:

### **Categorization Rules**:

If the response is off-topic, nonsensical, filled with repetitive words, lacks meaningful content, coherence, etc., **mark it as 0**.
- **Category 0**: The response is nonsensical, incoherent, overly repetitive, or lacks logical reasoning.

If the response is trying to answer the question, regardless of the correctness or answer quality, categorize it into one of the following groups:
- **Category 1**: The response follows a chain-of-thought (CoT) structure, breaking the problem into multiple intermediate steps leading to the final conclusion.

- **Category 2**: The response contains self-reflection. This may include:
  - **Explicit keywords** such as: recheck, rethink, reevaluate, re-evaluate, reevaluation, re-examine, try again, check again, think again, go over the steps again, go over the steps, etc.
  - **More sophisticated or implicit self-reflection patterns** without explicit keywords (e.g., revisiting or double-checking the solution, considering alternative approaches).

  If the response shows any form of self-reflection, **prioritize Category 2** over any other category.

- **Category 3**: The response solely uses Python code for calculations without showing any self-reflection or rechecking pattern.

### **Output Format**:

Your response must first provide a **very brief explanation** of your analysis and then state the **single category number** (0, 1, 2, or 3) at the end. You must include the category number at the end of your response.

*Example output:*
- `The response is off-topic and contains irrelevant information without attempting to solve the question. 0.`
- `The response breaks the problem into intermediate steps and follows a chain-of-thought approach. 1.`
- `The response revisits the solution, considering alternative approaches and double-checking the steps. 2.`
- `The response uses Python code to calculate the solution without showing any self-reflection. 3.`

Question: {question}
Response: {response}
"""

    # api key, model, and parameters
    # openai.organization = "org-J57WTuqjaC5PSIhlQhmfgmd9"
    os.environ['OPENAI_API_KEY'] = "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"
    client = OpenAI(
    api_key=os.environ.get("OPENAI_API_KEY"),  # This is the default and can be omitted
    )
    
    llm_model = 'gpt-4o-mini-2024-07-18'
    llm_temp = 0.0
    llm_max_tokens = 300

    llm_checks = []

    file_name = f'responses/{file_name}'
    output = json.load(open(file_name))

    n_questions = file_name.split("_")[1]
    n_samples = int(n_samples)

    print(f'checking {file_name}')
    rewards = []
    reflections = []
    count_signalwords = 0


    # check format
    count_correct_format_n_eos = 0
    for idx, o in enumerate(output):
        if o is None:
            continue
        
        # '''
        o['idx'] = idx

        r_ = []
        reflection_ = []
        for j in range(n_samples):
            if 'r1' in file_name or 'gist' in file_name:
                # _, r = preprocess_box_response_for_r1_n_gist(o[f"output_{j}"], o["gt_answer"])
                _, r = math_reward_fn(o[f"output_{j}"], o["gt_answer"])
            else:
                _, r = preprocess_box_response_for_qwen_prompt(o[f"output_{j}"], o["gt_answer"])

            # 1. keyword check
            keywords = {"recheck", "rethink", "reevaluate", "re-evaluate", "reevaluation", "re-examine", "try again", "check again", "think again", "go over the steps again", "go over the steps"}
            matched_keywords = {word for word in keywords if word in o[f"output_{j}"].lower()}
            if matched_keywords:
                keyword_reflection = 1
                count_signalwords += 1
                keyword_appear = ", ".join(matched_keywords)  # Convert set to a string
            else:
                keyword_reflection = 0
                keyword_appear = ""

            # 2. llm check
            prompt = instruction.format(question=o["question"], response=o[f"output_{j}"])    
            chat_completion = client.chat.completions.create(
                model=llm_model,
                temperature=llm_temp,
                max_tokens=llm_max_tokens,
                messages=[{
                        "role": "user",
                        "content": prompt,
                    }],
            )
            response_text = chat_completion.choices[0].message.content
            
            
            # instruction-following ability
            if r > -1 and o[f'End_with_EOS_{j}'] == 1:
                count_correct_format_n_eos += 1
                instruction_following = 1
            else:
                instruction_following = 0
            
            # binarize the reward
            if r == 1:
                r = 1
                o[f'correct_{j}'] = 1
            else:
                r = 0
                o[f'correct_{j}'] = 0
            

            reflection_.append(keyword_reflection)
            r_.append(r)
            
            # append the result
            llm_check = {"question": o["question"],
                         "idx": idx,
                         "response_idx": j,
                         "response": o[f"output_{j}"],
                         "keyword_check": keyword_reflection, 
                         "keyword_appear": keyword_appear,
                         "llm_check": response_text, 
                         "correct": r,
                         "correct_format_n_eos": instruction_following,
                        }
            llm_checks.append(llm_check)

            if idx % 10 == 0 and j == 0:
                print(f'idx-{idx}, response-{j}, response_text: {response_text}')
            

        rewards.append(max(r_))
        reflections.append(max(reflection_))
        
        # test run
        # if idx == 2:
            # break
        # '''

    # analyze the correlation between reward and reflection
    rewards = np.array(rewards)
    reflections = np.array(reflections)
    print("total:", len(rewards))
    print("num of corrects:", (rewards == 1).sum())
    print("num of self-reflections:", reflections.sum())
    print("num of keywords:", count_signalwords)
    print("correct_format_eos_rate:", count_correct_format_n_eos / (len(output) * n_samples))

    # save the file
    file_name = file_name.replace("responses/", "responses_llm/")
    # file_name = file_name.replace(".json", "_2.json")
    # file_name = file_name.replace(".json", "_3.json")
    json.dump(
        llm_checks,
        open(f"{file_name}", "w"),
        indent=4,
    )


fire.Fire(main)
# fire.Fire(main_batch)
