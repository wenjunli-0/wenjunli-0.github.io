import json
import os
from glob import glob

import fire


def is_valid_data(data: dict) -> bool:
    if data is None:
        return False
    if "error" in data:
        return False
    return True

def merge(source_dir: str, target_dir: str):
    fns = sorted(list(glob(f"{source_dir}/*.json")))
    data_list = []
    for fn in fns:
        with open(fn, "r") as f:
            data = json.load(f)
        data_list.append(data)
    
    merged_data_list = []
    for i in range(len(data_list[0])):
        if any(not is_valid_data(data_list[j][i]) for j in range(len(data_list))):
            print(f"Invalid data at index {i}")
            continue
        
        merged_data = {k:v for k,v in data_list[0][i].items() if k not in ["output_0", "End_with_EOS_0"]}
        
        for j in range(len(data_list)):
            merged_data[f"output_{j}"] = data_list[j][i]["output_0"]
            merged_data[f"End_with_EOS_{j}"] = data_list[j][i]["End_with_EOS_0"]
        merged_data_list.append(merged_data)

    nq = len(merged_data_list)
    n_samples = len(data_list)
    tag = os.path.basename(source_dir)
    target_file = os.path.join(target_dir, f"nq_{nq}_nsamp_{n_samples}_{tag}.json")
    with open(target_file, "w") as f:
        json.dump(merged_data_list, f, indent=4)

    print(f"Merged {n_samples} files from {source_dir} to {target_file}")

def should_add_end_word(output: str): 
    output = output.strip()

    if output.endswith("</answer>"):
        return False
    elif "<answer>" in output:
        return True 
    else:
        return False

def add_end_word(file_path: str, n_samp: int):
    with open(file_path, "r") as f:
        data = json.load(f)
    
    for item in data:
        for i in range(n_samp):
            o = item[f"output_{i}"]
            e = item[f"End_with_EOS_{i}"]
            if e and should_add_end_word(o):
                item[f"output_{i}"] = o + "</answer>"
    
    save_path = file_path.replace(".json", "_processed.json")
    with open(save_path, "w") as f:
        json.dump(data, f, indent=4)
    
    print(f"Added end word to {file_path} and saved to {save_path}")

def truncate_end_word(file_path: str, n_samp: int):
    with open(file_path, "r") as f:
        data = json.load(f)
    
    for item in data:
        for i in range(n_samp):
            o = item[f"output_{i}"]
            e = item[f"End_with_EOS_{i}"]
            if "</answer>" in o:
                item[f"output_{i}"] = o[:o.find("</answer>") + len("</answer>")]

    save_path = file_path.replace(".json", "_processed.json")
    with open(save_path, "w") as f:
        json.dump(data, f, indent=4)
    
    print(f"Truncated end word to {file_path} and saved to {save_path}")
    

if __name__ == "__main__":
    fire.Fire({
        "merge": merge, 
        "add_end_word": add_end_word, 
        "truncate_end_word": truncate_end_word
    })
