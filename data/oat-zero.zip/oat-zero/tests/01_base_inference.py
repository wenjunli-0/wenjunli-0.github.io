import json

import fire
import vllm

from transformers import AutoTokenizer
import sys


"""
Example usage:

# qwen template
python tests/01_base_inference.py --data_path ./data/math_train_500.json --model_name Qwen/Qwen2.5-7B --max_tokens 1500 --temperature 0.3 --n_samples 8


# r1 template
python tests/01_base_inference.py --data_path ./data/math_train_500_r1_v2.json --model_name meta-llama/Llama-3.1-8B --max_tokens 1500 --temperature 0.1 --n_samples 8

python tests/01_base_inference.py --data_path ./data/math_train_500_r1_v2.json --model_name HuggingFaceTB/FineMath-Llama-3B --max_tokens 1500 --temperature 0.1 --n_samples 8

python tests/01_base_inference.py --data_path ./data/math_train_500_r1_v2.json --model_name deepseek-ai/deepseek-math-7b-base --max_tokens 1500 --temperature 0.1 --n_samples 8
"""




def main(
    model_name: str = "Qwen/Qwen2.5-7B",   # model list: Qwen/Qwen2.5-Math-1.5B, Qwen/Qwen2.5-Math-7B, Qwen/Qwen2.5-7B,
                                           # deepseek-ai/deepseek-math-7b-base, deepseek-ai/deepseek-math-7b-instruct,
                                           # meta-llama/Llama-3.2-1B, meta-llama/Llama-3.1-8B, meta-llama/Llama-3.2-3B
                                           # microsoft/rho-math-7b-v0.1
    data_path: str = "./data/math_level3to5_data_processed_with_qwen_prompt.json",
    temperature: float = 0.3,
    max_tokens: int = 4096,  # temperature for sampling
    n: int = 500,  # num of test samples
    n_samples: int = 1,  # num of samples generated for each test sample
    save: bool = True,
):  

    if 'deepseek' in model_name or 'llama' in model_name or 'microsoft' in model_name:
        model = vllm.LLM(model_name, swap_space=16)
    else:
        model = vllm.LLM(model_name)
    data = json.load(open(data_path))

    # Load tokenizer (replace with your specific model)
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    sampling_params = vllm.SamplingParams(
        n=n_samples,
        temperature=temperature,
        top_p=0.9,
        max_tokens=max_tokens,
        # stop=["\n\nQuestion", "\n\nProblem"],
        logprobs=2,
    )

    prompts = [x["input"] for x in data][:n]

    if 'deepseek' in model_name or 'llama' in model_name:
    # if 'deepseek' in model_name:
        outputs = []
        batch_size = 10     # batch size for DeepSeek models
        for i in range(0, n, batch_size):
            batch_outputs = model.generate(prompts[i:i+batch_size], sampling_params)
            outputs.extend(batch_outputs)
    else:
        # send all prompts
        outputs = model.generate(prompts, sampling_params)

    for i, d in enumerate(data[:n]):
        # d[f"output_{j}"] = outputs[i].outputs[i].text

        for j in range(n_samples):
            d[f"output_{j}"] = outputs[i].outputs[j].text
            d[f'End_with_EOS_{j}'] = tokenizer.eos_token_id in outputs[i].outputs[j].token_ids

    # compute the rate of ending with EOS
    total_responses = n * n_samples
    count_end_with_eos = 0
    for i in range(n):
        for j in range(n_samples):
            count_end_with_eos += data[i][f'End_with_EOS_{j}']
    rate_end_with_eos = count_end_with_eos / total_responses
    print(f"Rate of ending with EOS: {rate_end_with_eos}")

    model_name = model_name.replace("/", "_")
    if save:
        if 'r1' in data_path:
            # filename = f"responses/{model_name}_{n}_{n_samples}_{temperature}_r1.json"
            filename = f"responses/{model_name}_{n}_{n_samples}_{temperature}_r1_v2.json"
        elif 'gist' in data_path:
            filename = f"responses/{model_name}_{n}_{n_samples}_{temperature}_gist.json"
        elif 'orz' in data_path:
            filename = f"responses/{model_name}_{n}_{n_samples}_{temperature}_orz.json"
        elif 'raw' in data_path:
            filename = f"responses/{model_name}_{n}_{n_samples}_{temperature}_raw.json"
        else:
            filename = f"responses/{model_name}_{n}_{n_samples}_{temperature}.json"
        json.dump(data, open(filename, "w"), indent=4)
        print(f"Saved to {filename}")
        
fire.Fire(main)
print("Done!")
