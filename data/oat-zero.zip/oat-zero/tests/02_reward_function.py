import json
import re
import sys

import fire
import numpy as np

# from oat_zero.qwen_math_eval_toolkit.grader import math_equal
# from oat_zero.qwen_math_eval_toolkit.parser import extract_answer as math_extract_answer

from reward_func import extract_answer, grade_answer_mathd, grade_answer_sympy

"""
Example usage:

# qwen template
python tests/02_reward_function.py --file_name Qwen_Qwen2.5-Math-1.5B_500_8_0.3.json --n_samples 8

# r1 template

python tests/02_reward_function.py --file_name meta-llama_Llama-3.1-8B_500_8_0.1_r1_v2.json --n_samples 8

python tests/02_reward_function.py --file_name HuggingFaceTB_FineMath-Llama-3B_500_8_0.1_r1_v2.json --n_samples 8

python tests/02_reward_function.py --file_name deepseek-ai_deepseek-math-7b-base_500_8_0.1_r1_v2.json --n_samples 8
"""

# python tests/02_reward_function.py --file_name Qwen_Qwen2.5-7B_500_8_1.0.json --n_samples 8


def preprocess_box_response_for_qwen_prompt(sequence, answer):
    # breakpoint()
    model_output = re.sub(
        r"^.*?<\|im_start\|>assistant",
        "<|im_start|>assistant",
        sequence,
        flags=re.DOTALL,
        count=1,
    )
    stop_words = ["</s>", "<|im_end|>", "<|endoftext|>"]
    for stop_word in stop_words:
        if stop_word in model_output:
            model_output = model_output.split(stop_word)[0].strip()
    extract_answer = math_extract_answer(
        model_output, data_name="math"
    )  # TODO: check the data_name, hard code here for now

    if math_equal(prediction=extract_answer, reference=answer):
        box_match = 1.0
    else:
        box_match = -0.5

    if "boxed" not in model_output:
        box_match = -1.0

    return "", box_match


def preprocess_box_response_for_r1_n_gist(sequence, answer):
    """
    instruction_prompt = A conversation between User and Assistant. The user asks a question, and the Assistant solves it. The assistant first thinks about the reasoning process in the mind and then provides the user with the answer. The reasoning process and answer are enclosed within <think> </think> and <answer> </answer> tags, respectively, i.e., <think> reasoning process here </think> <answer> answer here </answer>. User: {d['problem']}. Assistant:

    example_output = "<think> 30 = 2 x 3 x 5, 40 = 2 x 2 x 2 x 5, 16 = 2 x 2 x 2 x 2. The smallest positive integer that is a multiple of both 30 and 40 but not a multiple of 16 is 120 = 2 x 2 x 2 x 3 x 5. </think> <answer> 120 </answer>."
    """
    # detect the answer between <answer> </answer> tags
    match = re.search(r"<answer>\s*(.*?)\s*</answer>", sequence)
    if match:
        extracted_answer = match.group(1)  # Assign extracted answer to a variable
    else:
        extracted_answer = None
    if extracted_answer is None:
        return "", -1
    else:
        if math_equal(prediction=extracted_answer, reference=answer):
            return "", 1
        else:
            return "", -0.5


def grade(model_answer: str, gt_answer: str):
    if "\\boxed" in gt_answer:
        gt_answer = extract_answer(gt_answer)
    return grade_answer_mathd(model_answer, gt_answer) or grade_answer_sympy(
        model_answer, gt_answer
    )


def math_reward_fn(model_response, gt_answer):
    if "</answer>" in model_response:
        model_response = model_response[:model_response.find("</answer>") + len("</answer>")]
    if "</think> <answer>" in model_response and "</answer>" in model_response:
    # if "</answer>" in model_response:
        model_answer = model_response.split("<answer>")[-1].replace("</answer>", "")
        if "\\boxed" in model_answer:
            model_answer = extract_answer(model_answer)
            if model_answer is None:
                return {"formatted": True}, 0.0
        if isinstance(gt_answer, float) or isinstance(gt_answer, int):
            gt_answer = str(gt_answer)
        if isinstance(gt_answer, str):
            is_correct = grade(model_answer, gt_answer)
        elif isinstance(gt_answer, list):
            is_correct = False
            for gt in gt_answer:
                is_correct |= grade(model_answer, gt)
        if is_correct:
            return {"formatted": True}, 1.0  # Correctness reward.
        else:
            return (
                {"formatted": True},
                0.0,
            )  # Formatted but wrong answer; no format reward to avoid hacking.
    else:
        return {"formatted": False}, 0.0  # Unformatted.


def main(file_name: str = "output_Qwen_Qwen2.5-Math-7B_1000.json", n_samples: int = 1):
    
    model_name = file_name.split("_")[0]
    file_name = f'responses/{file_name}'
    output = json.load(open(file_name))

    n_questions = file_name.split("_")[1]
    n_samples = int(n_samples)

    print(f'Processing {n_questions} questions with {n_samples} responses for each question')
    rewards = []
    reflections = []
    reflections_per_level = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    count_end_with_eos = 0
    count_signalwords = 0

    # check format
    count_correct_format = 0
    count_correct_answer_n_eos = 0
    count_correct_format_n_eos = 0
    for idx, o in enumerate(output):
        # Only check the first output; this is NOT correct if we have n_sample > 1.
        # (To Wenjun) Please re-write another file to handle the logic to check correctness
        # of all outputs.
        o['idx'] = idx

        r_ = []
        reflection_ = []
        for j in range(n_samples):
            if 'r1' in file_name or 'gist' in file_name:
                _, r = preprocess_box_response_for_r1_n_gist(o[f"output_{j}"], o["gt_answer"])
            else:
                _, r = preprocess_box_response_for_qwen_prompt(o[f"output_{j}"], o["gt_answer"])
            if 'Qwen' in model_name:
                '''
                clear signal: recheck, rethink, try again;
                ambiguous signal: reevaluat, review;
                '''
                keywords = {"recheck", "rethink", "try again"}
            elif 'deepseek' in model_name:
                '''
                clear signal: reevaluate, reevaluation;
                '''
                keywords = {"reevaluate", "reevaluation", "recheck", "rethink", "check again", "re-evaluate", "try again", "re-examine", "try again", "think again", "go over the steps again"}
                # keywords = {"reevaluate", "reevaluation"}
            elif 'llama' in model_name:
                '''
                clear signal: None
                '''
                keywords = {"recheck", "rethink", "check again", "re-evaluate", "try again", "re-examine", }
            elif 'microsoft' in model_name:
                '''
                # qwen instruction:
                clear signal: recheck, rethink; 

                # gist instruction:
                clear signal: recheck, check again, re-evaluate, try again, re-examine;
                '''
                keywords = {"recheck", "rethink", "check again", "re-evaluate", "try again", "re-examine", }
            
            if any(word in o[f"output_{j}"].lower() for word in keywords):
                reflection = 1
                count_signalwords += 1
            else:
                reflection = 0
            
            # count_end_with_eos
            '''
            if o[f'End_with_EOS_{j}'] == 1:
                count_end_with_eos += 1
            # check format and eos
            if r == 1 and o[f'End_with_EOS_{j}'] == 1:
                count_correct_answer_n_eos += 1
            if r > -1 and o[f'End_with_EOS_{j}'] == 1:
                count_correct_format_n_eos += 1
                count_correct_format += 1
            '''
            
            # binarize the reward
            if r == 1:
                r = 1
                o[f'correct_{j}'] = 1
            else:
                r = 0
                o[f'correct_{j}'] = 0
            
            '''
            if r == 1:
                print(f"question-{idx}, response-{j}, correct. Reflection: {reflection}")
            elif r == -0.5:
                print(f"question-{idx}, response-{j}, wrong. Reflection: {reflection}")
            elif r == -1:
                print(f"question-{idx}, response-{j}, not formatted. Reflection: {reflection}")
            '''

            reflection_.append(reflection)
            r_.append(r)

            '''
            # find out where the reflection does not help the correctness
            if r == 0 and reflection == 1:
                print(f"question-{idx}, reponse-{j}. Not useful reflection. r: {r}, reflection: {reflection}")
            '''


        # count the number of reflections per level
        '''
        if o['level'] == 'Level 1':
            reflections_per_level[1] += sum(reflection_)
        elif o['level'] == 'Level 2':
            reflections_per_level[2] += sum(reflection_)
        elif o['level'] == 'Level 3':
            reflections_per_level[3] += sum(reflection_)
        elif o['level'] == 'Level 4':
            reflections_per_level[4] += sum(reflection_)
        elif o['level'] == 'Level 5':
            reflections_per_level[5] += sum(reflection_)
        '''

        # check whether reflection helps the correctness
        '''
        if sum(r_) < n_samples and max(reflection_) == 1:
            print(f"question-{idx}. sum_r: {sum(r_)}, sum_reflection: {sum(reflection_)}.")
            indexes = [i for i, val in enumerate(reflection_) if val == 1]
            for idx in indexes:
                if r_[idx] == 1 and sum(r_) == 1:    
                    print(f"\t Useful reflection. idx_of_reflection: {reflection_.index(1)}, idx_of_correct: {idx}")
        '''
        rewards.append(max(r_))
        reflections.append(max(reflection_))


    # analyze the correlation between reward and reflection
    rewards = np.array(rewards)
    reflections = np.array(reflections)
    print("num of correct:", (rewards == 1).sum())
    print("num of reflections:", reflections.sum())
    print("num of signal words:", count_signalwords)
    # print("correlation:", np.corrcoef(rewards, reflections))
    print("precision:", round((rewards * reflections).sum() / reflections.sum(), 3))
    print("recall:", round((rewards * reflections).sum() / rewards.sum(), 3))
    # print("reflections_per_level:", reflections_per_level)
    # print("end_with_eos_rate:", count_end_with_eos / (len(output) * n_samples))
    print("correct_format_eos_rate:", count_correct_format_n_eos / (len(output) * n_samples))

    rewards = np.array(rewards)
    print("total:", len(rewards))
    print("correct count:", (rewards == 1).sum())
    # print("formatted count:", count_correct_format)
    # print("wrong count:", (rewards == -0.5).sum())
    # print("not formatted count:", (rewards == -1).sum())
    # print("mean score", rewards.mean())

    # save the file
    json.dump(
        output,
        open(f"{file_name}", "w"),
        indent=4,
    )


def main_batch(file_name: str = "output_Qwen_Qwen2.5-Math-7B_1000.json", n_samples: int = 1):
    file_list = [
        # "Qwen_Qwen2.5-3B_500_8_0.1.json",
        # "Qwen_Qwen2.5-3B_500_8_0.2.json",
        # "Qwen_Qwen2.5-3B_500_8_0.3.json",
        # "Qwen_Qwen2.5-3B_500_8_0.4.json",
        # "Qwen_Qwen2.5-3B_500_8_0.5.json",
        # "Qwen_Qwen2.5-3B_500_8_0.6.json",
        # "Qwen_Qwen2.5-3B_500_8_0.7.json",
        # "Qwen_Qwen2.5-3B_500_8_0.8.json",
        # "Qwen_Qwen2.5-3B_500_8_0.9.json",
        # "Qwen_Qwen2.5-3B_500_8_1.0.json",

        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.1.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.2.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.3.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.4.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.5.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.6.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.7.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.8.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.9.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_1.0.json",

        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.1_r1.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.2_r1.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.3_r1.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.4_r1.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.5_r1.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.6_r1.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.7_r1.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.8_r1.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_0.9_r1.json",
        # "meta-llama_Llama-3.2-3B-Instruct_500_8_1.0_r1.json",

        # "microsoft_rho-math-7b-v0.1_500_8_0.1_r1.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.2_r1.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.3_r1.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.4_r1.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.5_r1.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.6_r1.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.7_r1.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.8_r1.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.9_r1.json",
        # "microsoft_rho-math-7b-v0.1_500_8_1.0_r1.json",

        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.1.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.2.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.3.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.4.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.5.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.6.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.7.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.8.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.9.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_1.0.json",

        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.1_r1.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.2_r1.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.3_r1.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.4_r1.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.5_r1.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.6_r1.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.7_r1.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.8_r1.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_0.9_r1.json",
        # "deepseek-ai_DeepSeek-R1-Distill-Qwen-1.5B_500_8_1.0_r1.json",

        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.1_orz.json",
        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.2_orz.json",
        # "Qwen_Qwen2.5-Math-1.5B_500_8_0.3_orz.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_0.1_orz.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_0.2_orz.json",
        # "Qwen_Qwen2.5-Math-7B_500_8_0.3_orz.json",
        # "Qwen_Qwen2.5-7B_500_8_0.1_orz.json",
        # "Qwen_Qwen2.5-7B_500_8_0.2_orz.json",
        # "Qwen_Qwen2.5-7B_500_8_0.3_orz.json",

        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.1_r1.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.2_r1.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.3_r1.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.4_r1.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.5_r1.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.6_r1.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.7_r1.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.8_r1.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.9_r1.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_1.0_r1.json",

        # "DS_v3_base_500_8_0.1_r1.json",
        # "DS_v3_base_500_8_0.2_r1.json",
        # "DS_v3_base_500_8_0.3_r1.json",
        # "DS_v3_base_500_8_0.4_r1.json",
        # "DS_v3_base_500_8_0.5_r1.json",
        # "DS_v3_base_500_8_0.6_r1.json",
        # "DS_v3_base_500_8_0.7_r1.json",
        # "DS_v3_base_500_8_0.8_r1.json",
        # "DS_v3_base_500_8_0.9_r1.json",
        # "DS_v3_base_500_8_1.0_r1.json",

        # "meta-llama_Llama-3.1-8B_500_8_0.1_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.2_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.3_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.4_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.5_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.6_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.7_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.8_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_0.9_r1_v2.json",
        # "meta-llama_Llama-3.1-8B_500_8_1.0_r1_v2.json",

        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.1_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.2_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.3_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.4_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.5_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.6_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.7_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.8_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_0.9_r1_v2.json",
        # "HuggingFaceTB_FineMath-Llama-3B_500_8_1.0_r1_v2.json",

        # "deepseek-ai_deepseek-math-7b-base_500_8_0.1_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.2_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.3_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.4_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.5_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.6_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.7_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.8_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_0.9_r1_v2.json",
        # "deepseek-ai_deepseek-math-7b-base_500_8_1.0_r1_v2.json",

        # "microsoft_rho-math-7b-v0.1_500_8_0.1_r1_v2.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.2_r1_v2.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.3_r1_v2.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.4_r1_v2.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.5_r1_v2.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.6_r1_v2.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.7_r1_v2.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.8_r1_v2.json",
        # "microsoft_rho-math-7b-v0.1_500_8_0.9_r1_v2.json",
        # "microsoft_rho-math-7b-v0.1_500_8_1.0_r1_v2.json",

        "deepseek_v3_base_truncated_500_8_0.1_r1.json",
        "deepseek_v3_base_truncated_500_8_0.2_r1.json",
        "deepseek_v3_base_truncated_500_8_0.3_r1.json",
        "deepseek_v3_base_truncated_500_8_0.4_r1.json",
        "deepseek_v3_base_truncated_500_8_0.5_r1.json",
        "deepseek_v3_base_truncated_500_8_0.6_r1.json",
        "deepseek_v3_base_truncated_500_8_0.7_r1.json",
        "deepseek_v3_base_truncated_500_8_0.8_r1.json",
        "deepseek_v3_base_truncated_500_8_0.9_r1.json",
        "deepseek_v3_base_truncated_500_8_1.0_r1.json",
    ]

    num_responses = []
    num_corrects = []
    num_reflections = []
    num_signalwords = []
    rate_correct_format_n_eos_list = []
    for temp, file_name in enumerate(file_list):
        file_name = f'responses/{file_name}'

        output = json.load(open(file_name))
        n_samples = 8
        print(f'Processing {file_name}. Temperature = 0.{temp+1}')

        # check if the output is empty
        if len(output) == 0:
            print(f"Empty output: {file_name}")
            continue

        rewards = []
        reflections = []
        count_signalwords = 0

        # instruction following ability
        count_instruction_following = 0
        for idx, o in enumerate(output):
            if o is None:
                continue
            o['idx'] = idx

            r_ = []
            reflection_ = []
            for j in range(n_samples):
                if 'r1' in file_name or 'gist' in file_name:
                    # _, r = preprocess_box_response_for_r1_n_gist(o[f"output_{j}"], o["gt_answer"])
                    _, r = math_reward_fn(o[f"output_{j}"], o["gt_answer"])
                else:
                    _, r = preprocess_box_response_for_qwen_prompt(o[f"output_{j}"], o["gt_answer"])

                keywords = {"recheck", "rethink", "reevaluate", "re-evaluate", "reevaluation", "re-examine", "try again", "check again", "think again", "go over the steps again", "go over the steps"}
 
                if any(word in o[f"output_{j}"].lower() for word in keywords):
                    reflection = 1
                    count_signalwords += 1
                else:
                    reflection = 0
                
                # corret answer format and eos
                if r > -1 and o[f'End_with_EOS_{j}'] == 1:
                    count_instruction_following += 1
                
                # binarize the reward
                if r == 1:
                    r = 1
                    o[f'correct_{j}'] = 1
                else:
                    r = 0
                    o[f'correct_{j}'] = 0
                
                '''
                if r == 1:
                    print(f"question-{idx}, response-{j}, correct. Reflection: {reflection}")
                elif r == -0.5:
                    print(f"question-{idx}, response-{j}, wrong. Reflection: {reflection}")
                elif r == -1:
                    print(f"question-{idx}, response-{j}, not formatted. Reflection: {reflection}")
                '''

                reflection_.append(reflection)
                r_.append(r)

                '''
                # find out where the reflection does not help the correctness
                if r == 0 and reflection == 1:
                    print(f"question-{idx}, reponse-{j}. Not useful reflection. r: {r}, reflection: {reflection}")
                '''

            # check whether reflection helps the correctness
            '''
            if sum(r_) < n_samples and max(reflection_) == 1:
                print(f"question-{idx}. sum_r: {sum(r_)}, sum_reflection: {sum(reflection_)}.")
                indexes = [i for i, val in enumerate(reflection_) if val == 1]
                for idx in indexes:
                    if r_[idx] == 1 and sum(r_) == 1:    
                        print(f"\t Useful reflection. idx_of_reflection: {reflection_.index(1)}, idx_of_correct: {idx}")
            '''
            rewards.append(max(r_))
            reflections.append(max(reflection_))

        rewards = np.array(rewards)
        reflections = np.array(reflections)

        # analyze the correlation between reward and reflection
        num_response = rewards.shape[0]
        num_correct = (rewards == 1).sum()
        num_reflection = reflections.sum()
        rate_correct_format_n_eos = round((count_instruction_following / (500*n_samples)), 3)

        print("num of correct:", num_correct)
        print("num of reflections:", num_reflection)
        print("num of signal words:", count_signalwords)
        print("correct_format_eos_rate:", rate_correct_format_n_eos)

        num_responses.append(num_response)
        num_corrects.append(num_correct)
        num_reflections.append(num_reflection)
        num_signalwords.append(count_signalwords)
        rate_correct_format_n_eos_list.append(rate_correct_format_n_eos)

    print(f"num_responses: {num_responses}")    
    print(f"num_corrects: {num_corrects}")
    print(f"num_reflections: {num_reflections}")
    print(f"num_signalwords: {num_signalwords}")
    print(f"rate_correct_format_n_eos_list: {rate_correct_format_n_eos_list}")

    # save the file as txt to results/
    '''
    with open(f"results/{file_name.split('/')[-1].replace('.json', '.txt')}", "w") as f:
        f.write(f"num_corrects: {num_corrects}\n")
        f.write(f"num_reflections: {num_reflections}\n")
        f.write(f"num_signalwords: {num_signalwords}\n")
        f.write(f"rate_correct_format_n_eos_list: {rate_correct_format_n_eos_list}\n")
    '''

# fire.Fire(main)
fire.Fire(main_batch)
