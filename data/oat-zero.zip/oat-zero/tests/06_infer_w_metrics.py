import json

import fire
import vllm
import os
import numpy as np
import re

from transformers import AutoTokenizer
import sys
from oat_zero.qwen_math_eval_toolkit.grader import math_equal
from oat_zero.qwen_math_eval_toolkit.parser import \
    extract_answer as math_extract_answer


"""
Example usage:

python tests/06_infer_w_metrics.py --data_path ./data/math_train_500.json --model_name Qwen/Qwen2.5-7B --max_tokens 1500 --temperature 0.3 --n_samples 8

"""


def preprocess_box_response_for_qwen_prompt(sequence, answer):
    # breakpoint()
    model_output = re.sub(
        r"^.*?<\|im_start\|>assistant",
        "<|im_start|>assistant",
        sequence,
        flags=re.DOTALL,
        count=1,
    )
    stop_words = ["</s>", "<|im_end|>", "<|endoftext|>"]
    for stop_word in stop_words:
        if stop_word in model_output:
            model_output = model_output.split(stop_word)[0].strip()
    extract_answer = math_extract_answer(
        model_output, data_name="math"
    )  # TODO: check the data_name, hard code here for now

    if math_equal(prediction=extract_answer, reference=answer):
        box_match = 1.0
    else:
        box_match = -0.5

    if "boxed" not in model_output:
        box_match = -1.0

    return "", box_match


def preprocess_box_response_for_r1_n_gist(sequence, answer):
    """
    instruction_prompt = A conversation between User and Assistant. The user asks a question, and the Assistant solves it. The assistant first thinks about the reasoning process in the mind and then provides the user with the answer. The reasoning process and answer are enclosed within <think> </think> and <answer> </answer> tags, respectively, i.e., <think> reasoning process here </think> <answer> answer here </answer>. User: {d['problem']}. Assistant:

    example_output = "<think> 30 = 2 x 3 x 5, 40 = 2 x 2 x 2 x 5, 16 = 2 x 2 x 2 x 2. The smallest positive integer that is a multiple of both 30 and 40 but not a multiple of 16 is 120 = 2 x 2 x 2 x 3 x 5. </think> <answer> 120 </answer>."
    """
    # detect the answer between <answer> </answer> tags
    match = re.search(r"<answer>\s*(.*?)\s*</answer>", sequence)
    if match:
        extracted_answer = match.group(1)  # Assign extracted answer to a variable
    else:
        extracted_answer = None
    if extracted_answer is None:
        return "", -1
    else:
        if math_equal(prediction=extracted_answer, reference=answer):
            return "", 1
        else:
            return "", -0.5
                  


def main(
    model_name: str = "Qwen/Qwen2.5-7B",   # model list: Qwen/Qwen2.5-7B, Qwen/Qwen2.5-Math-1.5B, Qwen/Qwen2.5-Math-7B, 
                                           # deepseek-ai/deepseek-math-7b-base, deepseek-ai/deepseek-math-7b-instruct,
                                           # meta-llama/Llama-3.2-1B, meta-llama/Llama-3.1-8B, 
                                           # microsoft/rho-math-7b-v0.1
    data_path: str = "./data/math_level3to5_data_processed_with_qwen_prompt.json",
    temperature: float = 0.3,
    max_tokens: int = 4096,  # temperature for sampling
    n: int = 500,  # num of test samples
    n_samples: int = 1,  # num of samples generated for each test sample
    save: bool = True,
):  

    if 'deepseek' in model_name:
        print(f'Using DeepSeek model: {model_name}')
        model = vllm.LLM(model_name, swap_space=16)
    else:
        model = vllm.LLM(model_name)
    data = json.load(open(data_path))

    # Load tokenizer (replace with your specific model)
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    sampling_params = vllm.SamplingParams(
        n=n_samples,
        temperature=temperature,
        top_p=0.9,
        max_tokens=max_tokens,
        # stop=["\n\nQuestion", "\n\nProblem"],
        logprobs=2,
    )

    # ========== step-1: run inference ========== #
    prompts = [x["input"] for x in data][:n]

    if 'deepseek' in model_name:
        # send 5 prompts to the model at a time
        outputs = []
        batch_size = 10     # customize the batch_size
        for i in range(0, n, batch_size):
            batch_outputs = model.generate(prompts[i:i+batch_size], sampling_params)
            outputs.extend(batch_outputs)
    else:
        # send all prompts
        outputs = model.generate(prompts, sampling_params)
        
    for i, d in enumerate(data[:n]):
        for j in range(n_samples):
            d[f"output_{j}"] = outputs[i].outputs[j].text
            d[f'End_with_EOS_{j}'] = tokenizer.eos_token_id in outputs[i].outputs[j].token_ids

    # compute the rate of ending with EOS
    total_responses = n * n_samples
    count_end_with_eos = 0
    for i in range(n):
        for j in range(n_samples):
            count_end_with_eos += data[i][f'End_with_EOS_{j}']
    rate_end_with_eos = count_end_with_eos / total_responses

    model_name = model_name.replace("/", "_")
    os.makedirs("./responses", exist_ok=True)
    json.dump(
        data,
        open(f"./responses/{model_name}_{n}_{n_samples}_{temperature}.json", "w"),
        indent=4,
    )
    

    # ========== step-2: eval metrics ========== #
    model_name = file_name.split("_")[0]
    file_name = f'responses/{file_name}'
    output = json.load(open(file_name))

    n_questions = file_name.split("_")[1]
    n_samples = int(n_samples)

    print(f'Processing {n_questions} questions with {n_samples} responses for each question')
    rewards = []
    reflections = []
    count_end_with_eos = 0

    # check format and eos
    count_correct_format_n_eos = 0
    for idx, o in enumerate(output):
        o['idx'] = idx

        r_ = []
        reflection_ = []
        for j in range(n_samples):
            if 'r1' in file_name or 'gist' in file_name:
                _, r = preprocess_box_response_for_r1_n_gist(o[f"output_{j}"], o["gt_answer"])
            else:
                _, r = preprocess_box_response_for_qwen_prompt(o[f"output_{j}"], o["gt_answer"])

            # check self-reflection
            if 'Qwen' in model_name:
                '''
                clear signal: recheck, rethink, try again;
                ambiguous signal: reevaluat, review;
                '''
                keywords = {"recheck", "rethink", "try again"}
                
            elif 'deepseek' in model_name:
                '''
                clear signal: reevaluate, reevaluation;
                '''
                keywords = {"reevaluate", "reevaluation", "recheck", "rethink", "check again", "re-evaluate", "try again", "re-examine"}
            elif 'llama' in model_name:
                '''
                clear signal: None
                '''
                keywords = {"recheck", "rethink", "check again", "re-evaluate", "try again", "re-examine"}
            elif 'microsoft' in model_name:
                '''
                # qwen instruction:
                clear signal: recheck, rethink; 

                # gist instruction:
                clear signal: recheck, check again, re-evaluate, try again, re-examine;
                '''
                keywords = {"recheck", "rethink", "check again", "re-evaluate", "try again", "re-examine", }

            if any(word in o[f"output_{j}"].lower() for word in keywords):
                reflection = 1
            else:
                reflection = 0
            
            
            # check format and eos
            if r > -1 and o[f'End_with_EOS_{j}'] == 1:
                count_correct_format_n_eos += 1

            # binarize the reward
            if r == 1:
                r = 1
                o[f'correct_{j}'] = 1
            else:
                r = 0
                o[f'correct_{j}'] = 0

            reflection_.append(reflection)
            r_.append(r)

        rewards.append(max(r_))
        reflections.append(max(reflection_))


    # analyze the correlation between reward and reflection
    rewards = np.array(rewards)
    reflections = np.array(reflections)
    print("total:", len(rewards))
    print("num of correct:", (rewards == 1).sum())
    print("num of self-reflections:", reflections.sum())
    print("precision:", round((rewards * reflections).sum() / reflections.sum(), 3))
    print("recall:", round((rewards * reflections).sum() / rewards.sum(), 3))
    print("correct_format_eos_rate:", round(count_correct_format_n_eos / (len(output) * n_samples)), 3)

fire.Fire(main)
