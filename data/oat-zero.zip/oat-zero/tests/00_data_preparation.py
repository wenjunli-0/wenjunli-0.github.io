import json
import sys
import pandas as pd


def read_jsonl(file):
    data = []
    with open(file, 'r') as f:
        for line in f:
            data.append(json.loads(line))
    return data


file = '/careAIDrive/wenjun/r1_replication/oat-zero/data/math_train_7500_raw.jsonl'
data = read_jsonl(file)

# filter the data by level
new_data = []
levels = ['Level 1', 'Level 2', 'Level 3', 'Level 4', 'Level 5']
counts = [0, 0, 0, 0, 0]
for d in data:
    if d['level'] in levels:
        new_data.append(d)
        counts[levels.index(d['level'])] += 1
for i, l in enumerate(levels):
    print(f'{l}: {counts[i]}')
# print(f'total: {len(new_data)}')

# count the total subjects of the data
subjects = set()
for d in new_data:
    subjects.add(d['subject'])
num_subjects = len(subjects)
print(f'total subjects: {num_subjects}, {subjects}')


# select n samples from each level, and store as a new jsonl file. Each level has the same number of subjects
# n = 10
n = 100
n_questions = int(5 * n)
questions_per_subject_ = n // num_subjects
last = n - questions_per_subject_ * (num_subjects-1)
questions_per_subject = {
    'Prealgebra': questions_per_subject_, 
    'Intermediate Algebra': questions_per_subject_, 
    'Algebra': questions_per_subject_, 
    'Counting & Probability': questions_per_subject_, 
    'Number Theory': questions_per_subject_, 
    'Precalculus': questions_per_subject_, 
    'Geometry': last,
}
print(questions_per_subject)


new_file = f'/careAIDrive/wenjun/r1_replication/oat-zero/data/math_train_{n_questions}.jsonl'
with open(new_file, 'w') as f:
    for l in levels:
        for i, s in enumerate(subjects):
            count = 0
            for d in new_data:
                if d['level'] == l and d['subject'] == s:
                    f.write(json.dumps(d) + '\n')
                    count += 1
                    if count == questions_per_subject[s]:
                        break
print(f'New data saved to {new_file}')


# count the number of questions in the new file
new_data = read_jsonl(new_file)
counts = [0, 0, 0, 0, 0]
for d in new_data:
    counts[levels.index(d['level'])] += 1
for i, l in enumerate(levels):
    print(f'{l}: {counts[i]}')
print(f'total: {len(new_data)}')


# format the data
def format_data(input_file, output_file):
    new_data = read_jsonl(input_file)
    formatted_data_qwen = [
        {
            "input": f"<|im_start|>system\nPlease reason step by step, and put your final answer within \\boxed{{}}.<|im_end|>\n<|im_start|>user\n{d['problem']}<|im_end|>\n<|im_start|>assistant",
            "answer": d["answer"],
            "gt_answer": d["answer"],
            "subject": d["subject"],
            "level": d["level"],
            "question": d["problem"],
            "ground_truth_answer": d["answer"],
            "target": d["answer"]
        }
        for d in new_data
    ]

    formatted_data_r1 = [
        {
            "input": f"A conversation between User and Assistant. The user asks a question, and the Assistant solves it. The assistant first thinks about the reasoning process in the mind and then provides the user with the answer. The reasoning process and answer are enclosed within <think> </think> and <answer> </answer> tags, respectively, i.e., <think> reasoning process here </think> <answer> answer here </answer>. User: {d['problem']} Assistant:",
            "answer": d["answer"],
            "gt_answer": d["answer"],
            "subject": d["subject"],
            "level": d["level"],
            "question": d["problem"],
            "ground_truth_answer": d["answer"],
            "target": d["answer"]
        }
        for d in new_data
    ]

    formatted_data_r1_v2 = [
        {
            "input": f"A conversation between User and Assistant. The User asks a question, and the Assistant solves it. The Assistant first thinks about the reasoning process in the mind and then provides the User with the answer. The reasoning process is enclosed within <think> </think> and answer is enclosed within <answer> </answer> tags, respectively, i.e., <think> reasoning process here </think> <answer> answer here </answer>.\nUser: {d['problem']}\nAssistant: <think>",
            "answer": d["answer"],
            "gt_answer": d["answer"],
            "subject": d["subject"],
            "level": d["level"],
            "question": d["problem"],
            "ground_truth_answer": d["answer"],
            "target": d["answer"]
        }
        for d in new_data
    ]

    

    formatted_data_gist = [
        {
            "input": f"You are a helpful assistant designed to solve mathematical problems posed by the user. Please provide your response in the following format:\n\n<reasoning>\nStep-by-step reasoning goes here.\n</reasoning>\n\n<answer>\nFinal answer goes here.\n</answer>\n\nUser: {d['problem']}\nAssistant:",
            "answer": d["answer"],
            "gt_answer": d["answer"],
            "subject": d["subject"],
            "level": d["level"],
            "question": d["problem"],
            "ground_truth_answer": d["answer"],
            "target": d["answer"]
        }
        for d in new_data
    ]

    formatted_data_orz = [
        {
            "input": f"A conversation between User and Assistant. The user asks a question, and the Assistant solves it. The Assistant first thinks about the reasoning process in the mind and then provides the user with the answer. The reasoning process and answer are enclosed within <think> </think> and <answer> </answer> tags, respectively, i.e., <think> reasoning process here </think> <answer> answer here </answer>. User: You must put your answer inside <answer> </answer> tags, i.e., <answer> answer here </answer>. And your final answer will be extracted automatically by the \\boxed{{}} tag. User: {d['problem']}\nAssistant: <think>",
            "answer": d["answer"],
            "gt_answer": d["answer"],
            "subject": d["subject"],
            "level": d["level"],
            "question": d["problem"],
            "ground_truth_answer": d["answer"],
            "target": d["answer"]
        }
        for d in new_data
    ]

    formatted_data_raw = [
        {
            "input": f"{d['problem']}",
            "answer": d["answer"],
            "gt_answer": d["answer"],
            "subject": d["subject"],
            "level": d["level"],
            "question": d["problem"],
            "ground_truth_answer": d["answer"],
            "target": d["answer"]
        }
        for d in new_data
    ]

    # Write to a JSON file with correct formatting
    with open(output_file, "w", encoding="utf-8") as f:
        print(f"Formatting data to {output_file}")
        formatted_data = formatted_data_gist
        if 'r1' in output_file.split('/')[-1]:
            print('using r1 format')
            # formatted_data = formatted_data_r1
            formatted_data = formatted_data_r1_v2
        elif 'gist' in output_file.split('/')[-1]:
            print('using gist format')
            formatted_data = formatted_data_gist
            print('output_file:', output_file)
        elif 'orz' in output_file.split('/')[-1]:
            print('using orz format')
            formatted_data = formatted_data_orz
        elif 'raw' in output_file.split('/')[-1]:
            print('using raw format')
            formatted_data = formatted_data_raw
        else:
            print('using qwen format')
            formatted_data = formatted_data_qwen
        json.dump(formatted_data, f, indent=4)
    print(f"Formatted data saved to {output_file}")

# Input and output paths
input_file = new_file  

# different instruction templates
# size=500, 100 questions from each level
# output_file = f'/careAIDrive/wenjun/r1_replication/oat-zero/data/math_train_{n_questions}_raw.json'       # 500, raw, without any instruction
# output_file = f'/careAIDrive/wenjun/r1_replication/oat-zero/data/math_train_{n_questions}.json'       # 500
output_file = f'/careAIDrive/wenjun/r1_replication/oat-zero/data/math_train_{n_questions}_r1_v2.json'    # 500
# output_file = f'/careAIDrive/wenjun/r1_replication/oat-zero/data/math_train_{n_questions}_gist.json'  # 500
# output_file = f'/careAIDrive/wenjun/r1_replication/oat-zero/data/math_train_{n_questions}_orz.json'  # 500

# size=50, 10 questions from each level
# output_file = f'/careAIDrive/wenjun/r1_replication/oat-zero/data/math_train_{n_questions}.json'         # 50
# output_file = f'/careAIDrive/wenjun/r1_replication/oat-zero/data/math_train_{n_questions}_r1.json'         # 50


# Run the function
format_data(input_file, output_file)
