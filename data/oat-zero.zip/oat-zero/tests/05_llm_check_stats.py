import json
import re
import sys

import fire
import numpy as np

import os
import argparse
import time
from openai import OpenAI

# from oat_zero.qwen_math_eval_toolkit.grader import math_equal
# from oat_zero.qwen_math_eval_toolkit.parser import extract_answer as math_extract_answer

"""
Example usage:

cd /careAIDrive/wenjun/r1_replication/oat-zero/
module purge
module load Anaconda3
eval "$(conda shell.bash hook)"
conda activate llm

python tests/05_llm_check_stats.py --model_name Qwen_Qwen2.5-Math-1.5B --temp_list="[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]"
python tests/05_llm_check_stats.py --model_name Qwen_Qwen2.5-Math-7B --temp_list="[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]"
python tests/05_llm_check_stats.py --model_name Qwen_Qwen2.5-7B --temp_list="[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]"

python tests/05_llm_check_stats.py --model_name microsoft_rho-math-7b-v0.1 --temp_list="[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]"
python tests/05_llm_check_stats.py --model_name deepseek-ai_deepseek-math-7b-base --temp_list="[0.6, 0.7, 0.8, 0.9, 1.0]"
python tests/05_llm_check_stats.py --model_name meta-llama_Llama-3.1-8B --temp_list="[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]"
python tests/05_llm_check_stats.py --model_name HuggingFaceTB_FineMath-Llama-3B --temp_list="[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]"

python tests/05_llm_check_stats.py --model_name deepseek_v3_base_truncated --temp_list=[0.6, 0.7, 0.8, 0.9, 1.0]
"""


def main(model_name: str="Qwen_Qwen2.5-Math-1.5B", temp_list: list = None):
    if temp_list is None:
        temp_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]


    # api key, model, and parameters
    # openai.organization = "org-J57WTuqjaC5PSIhlQhmfgmd9"
    os.environ['OPENAI_API_KEY'] = "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"
    client = OpenAI(
    api_key=os.environ.get("OPENAI_API_KEY"),  # This is the default and can be omitted
    )
    llm_model = 'gpt-4o-mini-2024-07-18'
    llm_temp = 0.0
    llm_max_tokens = 100


    instruction = """The model analysis provided below needs to be categorized into one of four groups. The response might not explicitly mention a category number, so your task is to carefully read the analysis and infer the most appropriate category: 0, 1, 2, or 3.

### **Categorization Rules**:

- **Category 0**: The response is off-topic, nonsensical, overly repetitive, or lacks meaningful content, coherence, or logical reasoning.

If the response attempts to answer the question, regardless of its correctness or quality, assign one of the following categories:

- **Category 1**: The response follows a chain-of-thought (CoT) structure, breaking the problem into multiple intermediate steps leading to a final conclusion.

- **Category 2**: The response demonstrates self-reflection. This can include:
  - **Explicit self-reflection keywords** like: recheck, rethink, reevaluate, re-evaluate, reevaluation, re-examine, try again, check again, think again, go over the steps again, go over the steps.
  - **Implicit self-reflection patterns** like revisiting or double-checking the solution, or considering alternative approaches.

  **Prioritize Category 2** if any form of self-reflection is present, even if the response also includes Python code.

- **Category 3**: The response solely uses Python code for calculations without any signs of self-reflection or rechecking. If both Python code and self-reflection appear, **assign Category 2** instead.

Please read the following analysis and return the most fitting category number (0, 1, 2, or 3). No explanation is needed.

LLM Analysis: {analysis}
"""

    # response-level stats
    count_keyword = []
    count_reflection_keyword = []
    count_reflection_llm = []
    count_reflection_llm_correct = []
    count_reflection_llm_incorrect = []
    keyword_appear = set()

    for temp in temp_list:
        if 'deepseek' in model_name or 'llama' in model_name or 'Llama' in model_name:
            # file_name = f'responses_llm/{model_name}_500_8_{temp}_r1.json'        # v1
            # file_name = f'responses_llm/{model_name}_500_8_{temp}_r1_2.json'      # v2
            # file_name = f'responses_llm/{model_name}_500_8_{temp}_r1_3.json'      # v3
            file_name = f'responses_llm/{model_name}_500_8_{temp}_r1_v2.json'        # r1, v2 & v3
        else:
            # file_name = f'responses_llm/{model_name}_500_8_{temp}.json'           # v1
            # file_name = f'responses_llm/{model_name}_500_8_{temp}_2.json'         # v2
            file_name = f'responses_llm/{model_name}_500_8_{temp}_3.json'           # v3
        
        output = json.load(open(file_name))
        correct = 0
        keyword_count_per_word = 0           # keyword pool check
        keyword_count_per_response = 0           # keyword pool check
        llm_reflection = 0
        llm_reflection_correct = 0
        llm_reflection_incorrect = 0
        llm_check = []
        category = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0}

        print(f'Processing {file_name}. Temperature = {temp}')
        for idx, o in enumerate(output):
            response = o["response"]

            # keyword check
            keywords_v0 = {"recheck", "rethink", "reevaluate", "re-evaluate", "reevaluation", "re-examine", "try again", "check again", "think again", "go over the steps again", "go over the steps"}
            keywords_v1 = {"recheck", "rethink", "reassess", "reevaluate", "re-evaluate", "reevaluation", "re-examine", "reexamine", "reconsider", "reanalyze", "double-check", "check again", "think again", "verify again", "go over the steps"}
            
            keywords = keywords_v1
            keyword_count_per_word += sum(response.lower().count(keyword) for keyword in keywords)
            keyword_count_per_response += 1 if any(keyword in response.lower() for keyword in keywords) else 0

            correct += o["correct"]
            # keyword_reflection += o["keyword_check"]
            if o["keyword_appear"] != '':
                keyword_appear.add(o["keyword_appear"])
            
            # v1: directly categorize the llm_check
            '''
            if o["llm_check"].startswith("0"):
                category[0] += 1
            elif o["llm_check"].startswith("1"):
                category[1] += 1
            elif o["llm_check"].startswith("2"):
                category[2] += 1
                llm_check.append(o["llm_check"])
                llm_reflection += 1
            elif o["llm_check"].startswith("3"):
                category[3] += 1
            else:
                category[4] += 1
            '''

            # v2: off-topic or answering? categorize after analysis
            inference = False
            if inference:
                llm_analysis = o["llm_check_2"]
                prompt = instruction.format(analysis=llm_analysis)    
                chat_completion = client.chat.completions.create(
                    model=llm_model,
                    temperature=llm_temp,
                    max_tokens=llm_max_tokens,
                    messages=[{
                            "role": "user",
                            "content": prompt,
                        }],
                )
                response_text = chat_completion.choices[0].message.content

                o['category'] = response_text
                if response_text.startswith("0"):
                    category[0] += 1
                elif response_text.startswith("1"):
                    category[1] += 1
                elif response_text.startswith("2"):
                    category[2] += 1
                    llm_check.append(o["llm_check"])
                    llm_reflection += 1
                elif response_text.startswith("3"):
                    category[3] += 1
                else:
                    category[4] += 1
            else:
                # print idx if no category in the output
                '''
                if 'category' not in o:
                    index = o['idx']
                    response_idx = o['response_idx']
                    print(f'temp={temp}, idx={index}, response_idx={response_idx}')
                    continue
                response_text = o['category']
                '''

                # check the last 5 token
                # response_text = o['llm_check_2'][-10:]
                response_text = o['llm_check'][-3:]
                if '0' in response_text:
                    category[0] += 1
                elif '1' in response_text:
                    category[1] += 1
                elif '2' in response_text:
                    category[2] += 1
                    llm_check.append(o["llm_check"])
                    llm_reflection += 1
                elif '3' in response_text:
                    category[3] += 1
                else:
                    index = o['idx']


            if inference and idx % 100 == 0:
                print(f'temp={temp}, idx={idx}')
                json.dump(
                    output,
                    open(f"{file_name}", "w"),
                    indent=4,
                )

        # response-level stats
        count_keyword.append(keyword_count_per_word)
        count_reflection_keyword.append(keyword_count_per_response)
        count_reflection_llm.append(llm_reflection)
        count_reflection_llm_correct.append(llm_reflection_correct)
        count_reflection_llm_incorrect.append(llm_reflection_incorrect)

        # print("total:", len(output))
        # print("correct:", correct)
        # print("keyword_appear:", keyword_appear)
        # print("llm_check:", llm_check)

        # keyword_check = {
            # "word-level": keyword_count_per_word,
            # "response-level": keyword_count_per_response,
        # }
        # print('keyword-detection:', keyword_count_per_response)
        # print("llm-detection: count_reflection:", llm_reflection)
        # print("llm-detection: count_reflection in correct:", llm_reflection_correct)
        # print("llm-detection: count_reflection in incorrect:", llm_reflection_incorrect)
        print("category:", category)

    print("count_keyword:", count_keyword)
    print("count_reflection_keyword_per_response:", count_reflection_keyword)
    print("count_reflection_llm_per_response:", count_reflection_llm)
    # print("count_reflection_llm_correct_per_response:", count_reflection_llm_correct)
    # print("count_reflection_llm_incorrect_per_response:", count_reflection_llm_incorrect)
    # print("keyword_appeared:", keyword_appear)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name", type=str, default="Qwen_Qwen2.5-Math-1.5B")
    parser.add_argument("--temp_list", type=str, default="[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]")

    args = parser.parse_args()

    # Convert temp_list from string to actual list
    temp_list = eval(args.temp_list)
    
    fire.Fire(main)
