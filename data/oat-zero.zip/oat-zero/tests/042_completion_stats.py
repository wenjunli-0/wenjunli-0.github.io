import json
import re
import sys

import fire
import numpy as np

import os
from openai import OpenAI

from oat_zero.qwen_math_eval_toolkit.grader import math_equal
from oat_zero.qwen_math_eval_toolkit.parser import \
    extract_answer as math_extract_answer

"""
Example usage:


python tests/042_completion_stats.py --model_name Qwen_Qwen2.5-Math-1.5B
python tests/042_completion_stats.py --model_name Qwen_Qwen2.5-Math-7B
python tests/042_completion_stats.py --model_name Qwen_Qwen2.5-7B

python tests/042_completion_stats.py --model_name microsoft_rho-math-7b-v0.1
python tests/042_completion_stats.py --model_name deepseek-ai_deepseek-math-7b-base

python tests/042_completion_stats.py --model_name meta-llama_Llama-3.1-8B
python tests/042_completion_stats.py --model_name meta-llama_Llama-3.2-3B

python tests/05_llm_check_stats.py --model_name deepseek_math500_nq_500_nsamp_8_temp_0.0.json
"""


def main(model_name: str = "output_Qwen_Qwen2.5-Math-7B_1000.json"):
    
    file_name_raw = f'responses/{model_name}_500_1_0.0_raw.json'
    file_name = f'responses_llm/{model_name}_500_1_0.0_raw.json'
    output_raw = json.load(open(file_name_raw))
    output = json.load(open(file_name))

    '''
    # copy the difficulty level from raw output to the processed output
    for idx, o in enumerate(output):
        output[idx]["level"] = output_raw[idx]["level"]

    # dump the processed output to a file
    with open(file_name, "w") as f:
        json.dump(output, f, indent=4)
    sys.exit(0)
    '''

    print(f'checking {file_name}')

    difficulty_completion = {
        '1': 0,
        '2': 0,
        '3': 0,
        '4': 0,
        '5': 0,
    }
    difficulty_answering = {
        '1': 0,
        '2': 0,
        '3': 0,
        '4': 0,
        '5': 0,
    }
    question_completion = 0           # keyword pool check
    question_answering = 0           # keyword pool check
    other = 0

    for idx, o in enumerate(output):
        # completion or answering
        if o["llm_check"].startswith("0"):
            question_completion += 1
            difficulty_completion[o["level"].split(" ")[1]] += 1
        elif o["llm_check"].startswith("1"):
            question_answering += 1
            difficulty_answering[o["level"].split(" ")[1]] += 1
        else:
            other += 1

    print("total:", len(output))
    keyword_check = {
        "question-completion": question_completion,
        "question-answering": question_answering,
        "other": other,
    }
    print('llm detection:', keyword_check)
    print('difficulty completion', difficulty_completion)
    print('difficulty answering', difficulty_answering)


fire.Fire(main)
